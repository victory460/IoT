﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using IoTNorthApp.utils;
using IoTNorthApp.model;

namespace IoTNorthApp
{
    public partial class frmMain : Form
    {
        private Thread RefreshDataThread = null;//数据刷新线程
        private volatile bool Running = true;//刷新线程运行标记
        private List<System.Windows.Forms.Timer> Timers = null;//定时器

        public frmMain()
        {
            InitializeComponent();

            AddLog("认证成功", null);

            //初始化
            Timers = new List<System.Windows.Forms.Timer>();
            dtTimer.Value = DateTime.Now;

            //创建获取设备线程
            Thread dvThread = new Thread(RefreshDeviceList);
            dvThread.IsBackground = true;
            dvThread.Start();
        }

        private void RefreshDeviceList()
        {
            //获取设备线程
            Thread.Sleep(1000);
            GetDevices();
        }

        /// <summary>
        /// 获取设备
        /// </summary>
        private void GetDevices()
        {
            string url = string.Format("http://{0}:{1}/iocm/app/dm/v1.3.0/devices", Context.IP, Context.Port);
            Dictionary<string, string> param = new Dictionary<string, string>();
            param.Add("appId", Context.AppId);
            param.Add("pageNo", "0");
            param.Add("pageSize", "10");

            Dictionary<string, string> header = new Dictionary<string, string>();
            header.Add("Authorization", "Bearer " + Context.AccessToken);
            header.Add("app_key", Context.AppId);

            string body = HttpUtil.doGetWithParasForString(url, param, header);

            if (string.IsNullOrEmpty(body))
            {
                AddLog("获取设备列表失败", null);
                return;
            }

            DeviceModel devices = JsonUtil.jsonString2Obj<DeviceModel>(body);
            if (devices == null)
            {
                AddLog("无法读取设备列表结果", null);
                return;
            }
            if (devices.totalCount == 0)
            {
                AddLog("获取到0个设备", null);
                return;
            }

            AddLog("获取到" + devices.totalCount + "个设备", null);
            RefreshList(devices, null);
        }

        /// <summary>
        /// 刷新数据委托
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RefreshList(object sender, EventArgs e)
        {
            if (lbDeviceList.InvokeRequired)
            {
                EventHandler h = RefreshList;
                Invoke(h, new object[] { sender, e });
                return;
            }

            DeviceModel devices = (DeviceModel)sender;
            lbDeviceList.Items.Clear();
            lbDeviceList.Click -= lbDeviceList_Click;
            for (int i = 0; i < devices.totalCount; i++)
            {
                lbDeviceList.Items.Add(devices.devices[i].deviceId);
            }
            lbDeviceList.Click += lbDeviceList_Click;
        }

        private void lbDeviceList_Click(object sender, EventArgs e)
        {
            if (lbDeviceList.SelectedItem == null) return;

            Context.DeviceId = lbDeviceList.SelectedItem.ToString();
            tbSelectDeviceId.Text = Context.DeviceId;
            AddLog("选择了设备：" + Context.DeviceId, null);
        }

        /// <summary>
        /// 刷新数据线程
        /// </summary>
        /// <param name="state"></param>
        private void Run(object state)
        {
            Running = true;
            while (Running)
            {
                Thread.Sleep(1000);

                GetData();
            }
        }

        /// <summary>
        /// 刷新数据委托
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RefreshData(object sender, EventArgs e)
        {
            if (gbDataPanel.InvokeRequired)
            {
                EventHandler h = RefreshData;
                Invoke(h, new object[] { sender, e });
                return;
            }

            device device = (device)sender;
            foreach (service s in device.services)
            {
                if (s.data.ContainsKey("temperature"))
                {
                    int v = s.data["temperature"];
                    if (v >= 25 && v <= 35)
                    {
                        tbTemperature.Text = s.data["temperature"].ToString();
                    }
                }
                if (s.data.ContainsKey("humidity"))
                {
                    int v = s.data["humidity"];
                    if (v >= 25 && v <= 65)
                    {
                        tbHumidity.Text = s.data["humidity"].ToString();
                    }
                }
                if (s.data.ContainsKey("ntc"))
                {
                    int v = s.data["ntc"];
                    if (v >= 0 && v <= 127)
                    {
                        tbNTC.Text = s.data["ntc"].ToString();
                    }
                }
                if (s.data.ContainsKey("smoke"))
                {
                    int v = s.data["smoke"];
                    if (v >= 0 && v <= 127)
                    {
                        tbSmoke.Text = s.data["smoke"].ToString();
                    }
                }
                if (s.data.ContainsKey("co"))
                {
                    int v = s.data["co"];
                    if (v >= 0 && v <= 127)
                    {
                        tbCO.Text = s.data["co"].ToString();
                    }
                }
                if (s.data.ContainsKey("human"))
                {
                    int v = s.data["human"];
                    if (v >= 0 && v <= 1)
                    {
                        tbHuman.Text = s.data["human"].ToString();
                    }
                }
            }
        }

        /// <summary>
        /// 云端获取数据
        /// </summary>
        private void GetData()
        {
            if (String.IsNullOrEmpty(Context.DeviceId)) return;

            string url = string.Format("http://{0}:{1}/iocm/app/dm/v1.3.0/devices/{2}", Context.IP, Context.Port, Context.DeviceId);

            Dictionary<string, string> header = new Dictionary<string, string>();
            header.Add("Authorization", "Bearer " + Context.AccessToken);
            header.Add("app_key", Context.AppId);

            string body = HttpUtil.doGetWithParasForString(url, null, header);

            if (string.IsNullOrEmpty(body))
            {
                AddLog("获取设备信息失败", null);
                return;
            }

            device device = JsonUtil.jsonString2Obj<device>(body);
            if (device == null || device.services == null)
            {
                AddLog("无法读取设备列表结果", null);
                return;
            }

            RefreshData(device, null);
        }

        /// <summary>
        /// 打印日志窗口
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddLog(object sender, EventArgs e)
        {
            if (lstLogs.InvokeRequired)
            {
                EventHandler h = AddLog;
                Invoke(h, new object[] { sender, e });
                return;
            }

            int index = lstLogs.Items.Add(sender);
            index = lstLogs.Items.Add("");
            lstLogs.TopIndex = index;
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btExit_Click(object sender, EventArgs e)
        {
            Stop();
            Close();
        }

        /// <summary>
        /// 退出清理
        /// </summary>
        private void Stop()
        {
            if (Running) Running = false;

            if (RefreshDataThread != null)
            {
                RefreshDataThread.Abort();
            }
            RefreshDataThread = null;

            foreach (System.Windows.Forms.Timer t in Timers)
            {
                t.Stop();
                t.Enabled = false;
                t.Dispose();
            }

            Timers = null;
        }

        /// <summary>
        /// 开灯
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btOpenLight_Click(object sender, EventArgs e)
        {
            SwitchLight("1");
        }

        /// <summary>
        /// 关灯
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btCloseLight_Click(object sender, EventArgs e)
        {
            SwitchLight("0");
        }

        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="val">指令值</param>
        private void SwitchLight(string val)
        {
            if (String.IsNullOrEmpty(Context.DeviceId)) return;

            string url = string.Format("http://{0}:{1}/iocm/app/cmd/v1.3.0/devices/{2}/commands", Context.IP, Context.Port, Context.DeviceId);
            CommandModel cmd = new CommandModel();
            cmd.expireTime = 120;
            cmd.command = new command();
            cmd.command.method = "SWITCH_LIGHT";
            cmd.command.serviceId = "Light";
            cmd.command.paras = new paras();
            cmd.command.paras.value = val;

            Dictionary<string, string> header = new Dictionary<string, string>();
            header.Add("Authorization", "Bearer " + Context.AccessToken);
            header.Add("app_key", Context.AppId);

            string body = HttpUtil.doPostJson(url, header, JsonUtil.jsonObj2String(cmd));

            if (string.IsNullOrEmpty(body))
            {
                AddLog("获取设备信息失败", null);
                return;
            }

            AddLog(body, null);
        }

        /// <summary>
        /// 启动数据刷新线程
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btGetData_Click(object sender, EventArgs e)
        {
            if (RefreshDataThread != null)
            {
                Stop();
            }

            RefreshDataThread = new Thread(Run);
            RefreshDataThread.IsBackground = true;
            RefreshDataThread.Start();
        }

        /// <summary>
        /// 添加一个定时器
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btTimer_Click(object sender, EventArgs e)
        {
            //指令有0-9，0=关灯，1=开灯
            string cmd = null;
            if (rb2.Checked) cmd = "2";//开空调
            if (rb3.Checked) cmd = "3";//关空调
            if (rb4.Checked) cmd = "4";//开电饭锅
            if (rb5.Checked) cmd = "5";//关电饭锅
            if (rb6.Checked) cmd = "6";//开加湿器
            if (rb7.Checked) cmd = "7";//关加湿器
            if (rb8.Checked) cmd = "8";//开热水器
            if (rb9.Checked) cmd = "9";//关热水器

            if (string.IsNullOrEmpty(cmd)) return;

            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            int delay = (int)(dtTimer.Value - DateTime.Now).TotalMilliseconds;

            if (delay < 0) return;

            //启动定时器
            timer.Interval = delay;
            timer.Enabled = true;
            timer.Tag = cmd;
            timer.Tick += timer_Tick;
            timer.Start();

            Timers.Add(timer);//添加到列表

            AddLog("添加了一个定时时间，将在 " + timer.Interval / 1000 + " 秒后执行。", null);
        }

        /// <summary>
        /// 定时到事件
        /// </summary>
        /// <param name="sender">Timer自己</param>
        /// <param name="e"></param>
        private void timer_Tick(object sender, EventArgs e)
        {
            //取出cmd命令值，消除Timer
            System.Windows.Forms.Timer timer = (System.Windows.Forms.Timer)sender;
            string cmd = (string)timer.Tag;
            Timers.Remove(timer);
            timer.Stop();
            timer.Enabled = false;
            timer.Dispose();
            timer = null;
            SwitchLight(cmd);

            AddLog("已发送定时指令 " + cmd, null);
        }

        /// <summary>
        /// 启动智能模式，设备根据环境参数自动开关
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btStartSmart_Click(object sender, EventArgs e)
        {
            //发送命令
            SwitchLight("20");
        }

        /// <summary>
        /// 关闭智能模式，设备接收远程控制
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btCloseSmart_Click(object sender, EventArgs e)
        {
            //发送命令
            SwitchLight("21");
        }

    }
}
