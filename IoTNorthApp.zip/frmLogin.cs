﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IoTNorthApp.utils;

namespace IoTNorthApp
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();

            tbIP.Text = "112.93.129.154";
            tbPort.Text = "8740";
            tbAppId.Text = "G8S9tQeutEL4CE3TRLGtfRom3Oka";
            tbPassword.Text = "GJ1U6s8dIjeWkcyAxCitbHRlAOwa";
        }

        private void btVerify_Click(object sender, EventArgs e)
        {
            if (Login())
            {
                Context.AppId = tbAppId.Text;
                Context.IP = tbIP.Text;
                Context.Port = tbPort.Text;
                DialogResult = DialogResult.OK;
            }
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        /// <summary>
        /// 云端认证
        /// </summary>
        /// <returns></returns>
        private bool Login()
        {
            string url = string.Format("http://{0}:{1}/iocm/app/sec/v1.1.0/login", tbIP.Text, tbPort.Text);
            Dictionary<string, string> param = new Dictionary<string, string>();
            param.Add("appId", tbAppId.Text);
            param.Add("secret", tbPassword.Text);
            string body = HttpUtil.doPostFormUrlEncodedForString(url, param);
            if (string.IsNullOrEmpty(body))
            {
                Context.Error("认证失败");
                return false;
            }

            Dictionary<string, string> data = JsonUtil.jsonString2Obj<Dictionary<string, string>>(body);
            if (data == null)
            {
                Context.Error("无法读取认证结果");
                return false;
            }

            if (!data.ContainsKey("accessToken"))
            {
                Context.Error("认证没有返回Token数据");
                return false;
            }

            //保存令牌
            Context.AccessToken = data["accessToken"];
            return true;
        }
    }
}
