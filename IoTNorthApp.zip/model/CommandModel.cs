﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IoTNorthApp.model
{
    /// <summary>
    /// 下发指令类，用于序列化Json
    /// </summary>
    public class CommandModel
    {
        public int expireTime { get; set; }
        public command command { get; set; }
    }

    public class command
    {
        public string method { get; set; }
        public paras paras { get; set; }
        public string serviceId { get; set; }
    }

    public class paras
    {
        public string value { get; set; }
    }
}
