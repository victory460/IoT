﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace IoTNorthApp
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            using (frmLogin login = new frmLogin())
            {
                DialogResult rst = login.ShowDialog();
                if (rst != DialogResult.OK)
                {
                    return;
                }
            }

            if (string.IsNullOrEmpty(Context.AccessToken)) return;

            Application.Run(new frmMain());
        }
    }
}
