﻿namespace IoTNorthApp
{
    partial class frmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.lstLogs = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbDataPanel = new System.Windows.Forms.GroupBox();
            this.btGetData = new System.Windows.Forms.Button();
            this.tbHuman = new System.Windows.Forms.TextBox();
            this.tbCO = new System.Windows.Forms.TextBox();
            this.btCloseLight = new System.Windows.Forms.Button();
            this.tbSmoke = new System.Windows.Forms.TextBox();
            this.btOpenLight = new System.Windows.Forms.Button();
            this.tbNTC = new System.Windows.Forms.TextBox();
            this.tbHumidity = new System.Windows.Forms.TextBox();
            this.tbTemperature = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btExit = new System.Windows.Forms.Button();
            this.lbDeviceList = new System.Windows.Forms.ListBox();
            this.tbSelectDeviceId = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rb9 = new System.Windows.Forms.RadioButton();
            this.rb7 = new System.Windows.Forms.RadioButton();
            this.rb5 = new System.Windows.Forms.RadioButton();
            this.rb3 = new System.Windows.Forms.RadioButton();
            this.btTimer = new System.Windows.Forms.Button();
            this.rb8 = new System.Windows.Forms.RadioButton();
            this.rb6 = new System.Windows.Forms.RadioButton();
            this.rb4 = new System.Windows.Forms.RadioButton();
            this.rb2 = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dtTimer = new System.Windows.Forms.DateTimePicker();
            this.btStartSmart = new System.Windows.Forms.Button();
            this.btCloseSmart = new System.Windows.Forms.Button();
            this.gbDataPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstLogs
            // 
            this.lstLogs.BackColor = System.Drawing.SystemColors.Info;
            this.lstLogs.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lstLogs.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lstLogs.ForeColor = System.Drawing.Color.DarkRed;
            this.lstLogs.FormattingEnabled = true;
            this.lstLogs.HorizontalScrollbar = true;
            this.lstLogs.ItemHeight = 16;
            this.lstLogs.Location = new System.Drawing.Point(20, 513);
            this.lstLogs.Name = "lstLogs";
            this.lstLogs.Size = new System.Drawing.Size(801, 228);
            this.lstLogs.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "操作设备：";
            // 
            // gbDataPanel
            // 
            this.gbDataPanel.Controls.Add(this.btCloseSmart);
            this.gbDataPanel.Controls.Add(this.btStartSmart);
            this.gbDataPanel.Controls.Add(this.btGetData);
            this.gbDataPanel.Controls.Add(this.tbHuman);
            this.gbDataPanel.Controls.Add(this.tbCO);
            this.gbDataPanel.Controls.Add(this.btCloseLight);
            this.gbDataPanel.Controls.Add(this.tbSmoke);
            this.gbDataPanel.Controls.Add(this.btOpenLight);
            this.gbDataPanel.Controls.Add(this.tbNTC);
            this.gbDataPanel.Controls.Add(this.tbHumidity);
            this.gbDataPanel.Controls.Add(this.tbTemperature);
            this.gbDataPanel.Controls.Add(this.label7);
            this.gbDataPanel.Controls.Add(this.label6);
            this.gbDataPanel.Controls.Add(this.label5);
            this.gbDataPanel.Controls.Add(this.label4);
            this.gbDataPanel.Controls.Add(this.label3);
            this.gbDataPanel.Controls.Add(this.label2);
            this.gbDataPanel.Location = new System.Drawing.Point(23, 159);
            this.gbDataPanel.Name = "gbDataPanel";
            this.gbDataPanel.Size = new System.Drawing.Size(423, 321);
            this.gbDataPanel.TabIndex = 14;
            this.gbDataPanel.TabStop = false;
            this.gbDataPanel.Text = "上报数据";
            // 
            // btGetData
            // 
            this.btGetData.Location = new System.Drawing.Point(253, 25);
            this.btGetData.Name = "btGetData";
            this.btGetData.Size = new System.Drawing.Size(147, 45);
            this.btGetData.TabIndex = 20;
            this.btGetData.Text = "开始刷新数据";
            this.btGetData.UseVisualStyleBackColor = true;
            this.btGetData.Click += new System.EventHandler(this.btGetData_Click);
            // 
            // tbHuman
            // 
            this.tbHuman.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tbHuman.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbHuman.Location = new System.Drawing.Point(124, 271);
            this.tbHuman.Margin = new System.Windows.Forms.Padding(4);
            this.tbHuman.Name = "tbHuman";
            this.tbHuman.ReadOnly = true;
            this.tbHuman.Size = new System.Drawing.Size(100, 26);
            this.tbHuman.TabIndex = 25;
            // 
            // tbCO
            // 
            this.tbCO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tbCO.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbCO.Location = new System.Drawing.Point(124, 227);
            this.tbCO.Margin = new System.Windows.Forms.Padding(4);
            this.tbCO.Name = "tbCO";
            this.tbCO.ReadOnly = true;
            this.tbCO.Size = new System.Drawing.Size(100, 26);
            this.tbCO.TabIndex = 24;
            // 
            // btCloseLight
            // 
            this.btCloseLight.Location = new System.Drawing.Point(253, 260);
            this.btCloseLight.Name = "btCloseLight";
            this.btCloseLight.Size = new System.Drawing.Size(147, 45);
            this.btCloseLight.TabIndex = 16;
            this.btCloseLight.Text = "关灯";
            this.btCloseLight.UseVisualStyleBackColor = true;
            this.btCloseLight.Click += new System.EventHandler(this.btCloseLight_Click);
            // 
            // tbSmoke
            // 
            this.tbSmoke.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tbSmoke.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbSmoke.Location = new System.Drawing.Point(124, 183);
            this.tbSmoke.Margin = new System.Windows.Forms.Padding(4);
            this.tbSmoke.Name = "tbSmoke";
            this.tbSmoke.ReadOnly = true;
            this.tbSmoke.Size = new System.Drawing.Size(100, 26);
            this.tbSmoke.TabIndex = 23;
            // 
            // btOpenLight
            // 
            this.btOpenLight.Location = new System.Drawing.Point(253, 209);
            this.btOpenLight.Name = "btOpenLight";
            this.btOpenLight.Size = new System.Drawing.Size(147, 45);
            this.btOpenLight.TabIndex = 15;
            this.btOpenLight.Text = "开灯";
            this.btOpenLight.UseVisualStyleBackColor = true;
            this.btOpenLight.Click += new System.EventHandler(this.btOpenLight_Click);
            // 
            // tbNTC
            // 
            this.tbNTC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tbNTC.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbNTC.Location = new System.Drawing.Point(124, 139);
            this.tbNTC.Margin = new System.Windows.Forms.Padding(4);
            this.tbNTC.Name = "tbNTC";
            this.tbNTC.ReadOnly = true;
            this.tbNTC.Size = new System.Drawing.Size(100, 26);
            this.tbNTC.TabIndex = 22;
            // 
            // tbHumidity
            // 
            this.tbHumidity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tbHumidity.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbHumidity.Location = new System.Drawing.Point(124, 95);
            this.tbHumidity.Margin = new System.Windows.Forms.Padding(4);
            this.tbHumidity.Name = "tbHumidity";
            this.tbHumidity.ReadOnly = true;
            this.tbHumidity.Size = new System.Drawing.Size(100, 26);
            this.tbHumidity.TabIndex = 21;
            // 
            // tbTemperature
            // 
            this.tbTemperature.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tbTemperature.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbTemperature.Location = new System.Drawing.Point(124, 51);
            this.tbTemperature.Margin = new System.Windows.Forms.Padding(4);
            this.tbTemperature.Name = "tbTemperature";
            this.tbTemperature.ReadOnly = true;
            this.tbTemperature.Size = new System.Drawing.Size(100, 26);
            this.tbTemperature.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(23, 274);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 16);
            this.label7.TabIndex = 19;
            this.label7.Text = "是否有人：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(57, 142);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 16);
            this.label6.TabIndex = 18;
            this.label6.Text = "光照：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(23, 230);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 16);
            this.label5.TabIndex = 17;
            this.label5.Text = "一氧化碳：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(57, 186);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 16);
            this.label4.TabIndex = 16;
            this.label4.Text = "烟雾：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(57, 98);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "湿度：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(57, 54);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "温度：";
            // 
            // btExit
            // 
            this.btExit.Location = new System.Drawing.Point(671, 23);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(147, 53);
            this.btExit.TabIndex = 17;
            this.btExit.Text = "退出";
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // lbDeviceList
            // 
            this.lbDeviceList.FormattingEnabled = true;
            this.lbDeviceList.ItemHeight = 16;
            this.lbDeviceList.Location = new System.Drawing.Point(27, 57);
            this.lbDeviceList.Name = "lbDeviceList";
            this.lbDeviceList.Size = new System.Drawing.Size(621, 84);
            this.lbDeviceList.TabIndex = 18;
            // 
            // tbSelectDeviceId
            // 
            this.tbSelectDeviceId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tbSelectDeviceId.Location = new System.Drawing.Point(119, 24);
            this.tbSelectDeviceId.Name = "tbSelectDeviceId";
            this.tbSelectDeviceId.ReadOnly = true;
            this.tbSelectDeviceId.Size = new System.Drawing.Size(529, 26);
            this.tbSelectDeviceId.TabIndex = 19;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtTimer);
            this.groupBox1.Controls.Add(this.rb9);
            this.groupBox1.Controls.Add(this.rb7);
            this.groupBox1.Controls.Add(this.rb5);
            this.groupBox1.Controls.Add(this.rb3);
            this.groupBox1.Controls.Add(this.btTimer);
            this.groupBox1.Controls.Add(this.rb8);
            this.groupBox1.Controls.Add(this.rb6);
            this.groupBox1.Controls.Add(this.rb4);
            this.groupBox1.Controls.Add(this.rb2);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(452, 159);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(366, 321);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "定时控制";
            // 
            // rb9
            // 
            this.rb9.AutoSize = true;
            this.rb9.Location = new System.Drawing.Point(206, 277);
            this.rb9.Name = "rb9";
            this.rb9.Size = new System.Drawing.Size(90, 20);
            this.rb9.TabIndex = 37;
            this.rb9.TabStop = true;
            this.rb9.Text = "关热水器";
            this.rb9.UseVisualStyleBackColor = true;
            // 
            // rb7
            // 
            this.rb7.AutoSize = true;
            this.rb7.Location = new System.Drawing.Point(206, 234);
            this.rb7.Name = "rb7";
            this.rb7.Size = new System.Drawing.Size(90, 20);
            this.rb7.TabIndex = 36;
            this.rb7.TabStop = true;
            this.rb7.Text = "关加湿器";
            this.rb7.UseVisualStyleBackColor = true;
            // 
            // rb5
            // 
            this.rb5.AutoSize = true;
            this.rb5.Location = new System.Drawing.Point(206, 191);
            this.rb5.Name = "rb5";
            this.rb5.Size = new System.Drawing.Size(90, 20);
            this.rb5.TabIndex = 35;
            this.rb5.TabStop = true;
            this.rb5.Text = "关电饭锅";
            this.rb5.UseVisualStyleBackColor = true;
            // 
            // rb3
            // 
            this.rb3.AutoSize = true;
            this.rb3.Location = new System.Drawing.Point(206, 148);
            this.rb3.Name = "rb3";
            this.rb3.Size = new System.Drawing.Size(74, 20);
            this.rb3.TabIndex = 34;
            this.rb3.TabStop = true;
            this.rb3.Text = "关空调";
            this.rb3.UseVisualStyleBackColor = true;
            // 
            // btTimer
            // 
            this.btTimer.Location = new System.Drawing.Point(262, 32);
            this.btTimer.Name = "btTimer";
            this.btTimer.Size = new System.Drawing.Size(81, 41);
            this.btTimer.TabIndex = 33;
            this.btTimer.Text = "添加";
            this.btTimer.UseVisualStyleBackColor = true;
            this.btTimer.Click += new System.EventHandler(this.btTimer_Click);
            // 
            // rb8
            // 
            this.rb8.AutoSize = true;
            this.rb8.Location = new System.Drawing.Point(85, 277);
            this.rb8.Name = "rb8";
            this.rb8.Size = new System.Drawing.Size(90, 20);
            this.rb8.TabIndex = 32;
            this.rb8.TabStop = true;
            this.rb8.Text = "开热水器";
            this.rb8.UseVisualStyleBackColor = true;
            // 
            // rb6
            // 
            this.rb6.AutoSize = true;
            this.rb6.Location = new System.Drawing.Point(85, 234);
            this.rb6.Name = "rb6";
            this.rb6.Size = new System.Drawing.Size(90, 20);
            this.rb6.TabIndex = 31;
            this.rb6.TabStop = true;
            this.rb6.Text = "开加湿器";
            this.rb6.UseVisualStyleBackColor = true;
            // 
            // rb4
            // 
            this.rb4.AutoSize = true;
            this.rb4.Location = new System.Drawing.Point(85, 191);
            this.rb4.Name = "rb4";
            this.rb4.Size = new System.Drawing.Size(90, 20);
            this.rb4.TabIndex = 30;
            this.rb4.TabStop = true;
            this.rb4.Text = "开电饭锅";
            this.rb4.UseVisualStyleBackColor = true;
            // 
            // rb2
            // 
            this.rb2.AutoSize = true;
            this.rb2.Location = new System.Drawing.Point(85, 148);
            this.rb2.Name = "rb2";
            this.rb2.Size = new System.Drawing.Size(74, 20);
            this.rb2.TabIndex = 29;
            this.rb2.TabStop = true;
            this.rb2.Text = "开空调";
            this.rb2.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(71, 106);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 16);
            this.label9.TabIndex = 28;
            this.label9.Text = "设备选择：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 44);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 16);
            this.label8.TabIndex = 27;
            this.label8.Text = "定时设置:";
            // 
            // dtTimer
            // 
            this.dtTimer.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtTimer.Location = new System.Drawing.Point(109, 37);
            this.dtTimer.Name = "dtTimer";
            this.dtTimer.Size = new System.Drawing.Size(138, 26);
            this.dtTimer.TabIndex = 38;
            // 
            // btStartSmart
            // 
            this.btStartSmart.Location = new System.Drawing.Point(253, 85);
            this.btStartSmart.Name = "btStartSmart";
            this.btStartSmart.Size = new System.Drawing.Size(147, 45);
            this.btStartSmart.TabIndex = 39;
            this.btStartSmart.Text = "启动智能模式";
            this.btStartSmart.UseVisualStyleBackColor = true;
            this.btStartSmart.Click += new System.EventHandler(this.btStartSmart_Click);
            // 
            // btCloseSmart
            // 
            this.btCloseSmart.Location = new System.Drawing.Point(253, 136);
            this.btCloseSmart.Name = "btCloseSmart";
            this.btCloseSmart.Size = new System.Drawing.Size(147, 45);
            this.btCloseSmart.TabIndex = 40;
            this.btCloseSmart.Text = "关闭智能模式";
            this.btCloseSmart.UseVisualStyleBackColor = true;
            this.btCloseSmart.Click += new System.EventHandler(this.btCloseSmart_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 761);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tbSelectDeviceId);
            this.Controls.Add(this.lbDeviceList);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.gbDataPanel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstLogs);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Padding = new System.Windows.Forms.Padding(20);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "北向APP";
            this.gbDataPanel.ResumeLayout(false);
            this.gbDataPanel.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstLogs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbDataPanel;
        private System.Windows.Forms.Button btOpenLight;
        private System.Windows.Forms.Button btCloseLight;
        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.TextBox tbHuman;
        private System.Windows.Forms.TextBox tbCO;
        private System.Windows.Forms.TextBox tbSmoke;
        private System.Windows.Forms.TextBox tbNTC;
        private System.Windows.Forms.TextBox tbHumidity;
        private System.Windows.Forms.TextBox tbTemperature;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lbDeviceList;
        private System.Windows.Forms.TextBox tbSelectDeviceId;
        private System.Windows.Forms.Button btGetData;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btTimer;
        private System.Windows.Forms.RadioButton rb8;
        private System.Windows.Forms.RadioButton rb6;
        private System.Windows.Forms.RadioButton rb4;
        private System.Windows.Forms.RadioButton rb2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rb9;
        private System.Windows.Forms.RadioButton rb7;
        private System.Windows.Forms.RadioButton rb5;
        private System.Windows.Forms.RadioButton rb3;
        private System.Windows.Forms.DateTimePicker dtTimer;
        private System.Windows.Forms.Button btCloseSmart;
        private System.Windows.Forms.Button btStartSmart;
    }
}

