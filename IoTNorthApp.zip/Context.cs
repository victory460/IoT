﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace IoTNorthApp
{
    /// <summary>
    /// 全局变量
    /// </summary>
    public class Context
    {
        public static string IP = null;
        public static string Port = null;
        public static string AppId = null;
        public static string AccessToken = null;
        public static string DeviceId = null;

        public static void Error(string msg)
        {
            MessageBox.Show(msg, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
