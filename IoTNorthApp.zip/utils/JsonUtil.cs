﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace IoTNorthApp.utils
{
    public class JsonUtil
    {
        /// <summary>
        /// Json格式字符串反序列化至对象
        /// </summary>
        /// <typeparam name="T">泛型定义</typeparam>
        /// <param name="json">Json字符串</param>
        /// <returns>返回对象</returns>
        public static T jsonString2Obj<T>(string json) where T : class
        {
            JavaScriptSerializer js = new JavaScriptSerializer();

            try
            {
                return js.Deserialize<T>(json);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 对象序列化至Json格式字符串
        /// </summary>
        /// <typeparam name="T">泛型定义</typeparam>
        /// <param name="obj">泛型对象</param>
        /// <returns>Json格式字符串</returns>
        public static string jsonObj2String<T>(T obj) where T : class
        {
            JavaScriptSerializer js = new JavaScriptSerializer();
            try
            {
                return js.Serialize(obj);
            }
            catch
            {
                return null;
            }
        }
    }
}
