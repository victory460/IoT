﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;

namespace IoTNorthApp.utils
{
    public class HttpUtil
    {
        /// <summary>
        /// Post数据
        /// </summary>
        /// <param name="url">云端API地址</param>
        /// <param name="formParams">post数据，键值对</param>
        /// <returns>云端返回数据，字符串方式</returns>
        public static string doPostFormUrlEncodedForString(string url, Dictionary<string, string> formParams)
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);

            req.Method = "POST";

            StringBuilder post = new StringBuilder();
            foreach (KeyValuePair<string, string> p in formParams)
            {
                post.Append(p.Key + "=" + p.Value + "&");
            }
            string sData = post.ToString().TrimEnd('&');
            byte[] bData = Encoding.UTF8.GetBytes(sData);
            req.ContentLength = bData.Length;
            Stream reqStream = req.GetRequestStream();
            reqStream.Write(bData, 0, bData.Length);
            reqStream.Close();

            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
            Stream respStream = resp.GetResponseStream();
            StreamReader readStream;
            if (!string.IsNullOrEmpty(resp.CharacterSet))
            {
                Encoding encode = Encoding.GetEncoding(resp.CharacterSet);
                readStream = new StreamReader(respStream, encode);
            }
            else
            {
                readStream = new StreamReader(respStream);
            }
            string html = (readStream.ReadToEnd());
            readStream.Close();
            respStream.Close();
            resp.Close();

            return html;
        }

        /// <summary>
        /// Get数据
        /// </summary>
        /// <param name="url">云端API地址</param>
        /// <param name="param">Get参数，键值对</param>
        /// <param name="header">Http头数据，键值对，放置令牌及AppId</param>
        /// <returns>云端返回数据，字符串</returns>
        public static string doGetWithParasForString(string url, Dictionary<string, string> param, Dictionary<string, string> header)
        {
            string paramStr = null;
            if (param != null && param.Count > 0)
            {
                StringBuilder p = new StringBuilder();
                foreach (KeyValuePair<string, string> pm in param)
                {
                    p.Append(pm.Key + "=" + pm.Value + "&");
                }
                paramStr = p.ToString().TrimEnd('&');
            }

            if (!string.IsNullOrEmpty(paramStr))
            {
                url += "?" + paramStr;
            }

            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);

            req.Method = "GET";
            addRequestHeader(req, header);

            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
            Stream respStream = resp.GetResponseStream();
            StreamReader readStream;
            if (!string.IsNullOrEmpty(resp.CharacterSet))
            {
                Encoding encode = Encoding.GetEncoding(resp.CharacterSet);
                readStream = new StreamReader(respStream, encode);
            }
            else
            {
                readStream = new StreamReader(respStream);
            }
            string html = (readStream.ReadToEnd());
            readStream.Close();
            respStream.Close();
            resp.Close();

            return html;
        }

        /// <summary>
        /// 添加http头数据
        /// </summary>
        /// <param name="request">http请求对象</param>
        /// <param name="header">头数据，键值对</param>
        private static void addRequestHeader(HttpWebRequest request, Dictionary<string, string> header)
        {
            if (header == null)
            {
                return;
            }

            foreach (KeyValuePair<string, string> h in header)
            {
                if (h.Key.Equals("Content-Length", StringComparison.CurrentCultureIgnoreCase))
                {
                    continue;
                }

                request.Headers.Add(h.Key, h.Value);
            }
        }

        /// <summary>
        /// Post Json 数据
        /// </summary>
        /// <param name="url">云端API地址</param>
        /// <param name="header">http头数据</param>
        /// <param name="json">Json数据，以字符串格式</param>
        /// <returns>云端返回数据，字符串格式</returns>
        public static string doPostJson(string url, Dictionary<string, string> header, string json)
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.ContentType = "application/json";
            req.Method = "POST";
            addRequestHeader(req, header);

            byte[] bData = Encoding.UTF8.GetBytes(json);
            req.ContentLength = bData.Length;
            Stream reqStream = req.GetRequestStream();
            reqStream.Write(bData, 0, bData.Length);
            reqStream.Close();

            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
            Stream respStream = resp.GetResponseStream();
            StreamReader readStream;
            if (!string.IsNullOrEmpty(resp.CharacterSet))
            {
                Encoding encode = Encoding.GetEncoding(resp.CharacterSet);
                readStream = new StreamReader(respStream, encode);
            }
            else
            {
                readStream = new StreamReader(respStream);
            }
            string html = (readStream.ReadToEnd());
            readStream.Close();
            respStream.Close();
            resp.Close();

            return html;
        }
    }
}
