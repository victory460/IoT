package com.example.victory.myapplication1;

import android.app.Notification;
import android.app.NotificationManager;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;




public class MainActivity extends AppCompatActivity {
    int notificationId = 1001;
    String ip = "10.10.100.254";
    int port = 9000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView temp= (TextView)findViewById(R.id.tempValue);
        final TextView humi= (TextView)findViewById(R.id.humiValue);
        final TextView ntc= (TextView)findViewById(R.id.NTCValue);
        final TextView smoke= (TextView)findViewById(R.id.smokeValue);
        final TextView co= (TextView)findViewById(R.id.coValue);
        final TextView human= (TextView)findViewById(R.id.humanValue);

        final   Handler handler = new Handler()         //定义一个Handler用于线程间的消息 通信
        {
            @Override
            public void handleMessage(Message msg)   //重写消息处理函数
            {
                switch (msg.what)//根据消息的不同类型做相应的处理
                {
                    case 1:
                        temp.setText(msg.obj.toString());
                        break;
                    case 2:
                        humi.setText(msg.obj.toString());
                        break;
                    case 3:
                        ntc.setText(msg.obj.toString());
                        break;
                    case 4:
                        smoke.setText(msg.obj.toString());
                        break;
                    case 5:
                        co.setText(msg.obj.toString());
                        break;
                    case 6:
                        if(msg.obj.toString().indexOf("in")!=-1)
                        {
                            human.setText("有人");
                        }
                        if(msg.obj.toString().indexOf("out")!=-1)
                        {
                            human.setText("没人");
                        }
                        break;
                    case 7:
                        Notification notification  = new Notification.Builder(MainActivity.this)
                                .setContentTitle("智能家居")
                                .setContentText("烟雾过大,请注意") //也可以自定义显示的内容
                                .setSmallIcon(android.R.drawable.star_on)
                                //  .setContentIntent(pendingIntent)
                                .setAutoCancel(true)
                                //.addAction(android.R.drawable.ic_menu_gallery,
                                // "Open", pendingIntent)
                                .build();

                        notification.defaults |=Notification.DEFAULT_SOUND;
                        notification.defaults |=Notification.DEFAULT_VIBRATE;
                        NotificationManager notificationManager =
                                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                        notificationManager.notify(notificationId, notification);
                        break;
                    case 8:
                        Notification notification2  = new Notification.Builder(MainActivity.this)
                                .setContentTitle("智能家居")
                                .setContentText("CO浓度过大，请注意") //也可以自定义显示的内容
                                .setSmallIcon(android.R.drawable.star_on)
                                //  .setContentIntent(pendingIntent)
                                .setAutoCancel(true)
                                //.addAction(android.R.drawable.ic_menu_gallery,
                                // "Open", pendingIntent)
                                .build();

                        notification2.defaults |=Notification.DEFAULT_SOUND;
                        notification2.defaults |=Notification.DEFAULT_VIBRATE;
                        NotificationManager notificationManager2 =
                                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                        notificationManager2.notify(notificationId, notification2);
                        break;
                    case 9:
                        Notification notification3  = new Notification.Builder(MainActivity.this)
                                .setContentTitle("智能家居")
                                .setContentText("有人进入，请注意") //也可以自定义显示的内容
                                .setSmallIcon(android.R.drawable.star_on)
                                //  .setContentIntent(pendingIntent)
                                .setAutoCancel(true)
                                //.addAction(android.R.drawable.ic_menu_gallery,
                                // "Open", pendingIntent)
                                .build();

                        notification3.defaults |=Notification.DEFAULT_SOUND;
                        notification3.defaults |=Notification.DEFAULT_VIBRATE;
                        NotificationManager notificationManager3 =
                                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                        notificationManager3.notify(notificationId, notification3);
                        break;

                    default:
                        break;

                }

            }
        };
        //socket receive fun  //开启一个线程用于socket连接，WIFI通信，接收数据
        new Thread() {

            @Override
            public void run() {

                try {

                    Socket socket = new Socket(ip, port);
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(socket.getInputStream()));//字符形式

                    //------------------- read the response-----------------------------
                    boolean loop = true;

                    while (true)
                    { StringBuilder sb = new StringBuilder(2000);
                        while (loop)
                        {
                            Thread.sleep(50);

                            if (in.ready()) //ISR
                            {

                                int i = 0;
                                while (true)
                                {
                                    i = in.read();
                                    if (i=='#')break;

                                    sb.append((char) i);

                                }
                                loop = false;
                            }
                        }
                        loop=true;

                        //对接收到的数据进行解析，并执行；发送消息
                        Message message = new Message();
                        if (sb.indexOf("TempValue")!=-1)
                        {

                            String str=sb.toString();
                            String [] ParaStr=str.split("[-]");
                            Log.d("znjj", ParaStr[0]);
                            Log.d("znjj", ParaStr[1]);

                            message.what = 1;//种类
                            message.obj = ParaStr[1];
                        }

                        if (sb.indexOf("HumiValue")!=-1)
                        {

                            String str=sb.toString();
                            String [] ParaStr=str.split("[-]");
                            Log.d("znjj", ParaStr[0]);
                            Log.d("znjj", ParaStr[1]);

                            message.what = 2;//种类
                            message.obj = ParaStr[1];
                        }

                        if (sb.indexOf("NTCValue")!=-1)
                        {

                            String str=sb.toString();
                            String [] ParaStr=str.split("[-]");
                            Log.d("znjj", ParaStr[0]);
                            Log.d("znjj", ParaStr[1]);

                            message.what = 3;//种类
                            message.obj = ParaStr[1];
                        }

                        if (sb.indexOf("smokeValue")!=-1)
                        {

                            String str=sb.toString();
                            String [] ParaStr=str.split("[-]");
                            Log.d("znjj", ParaStr[0]);
                            Log.d("znjj", ParaStr[1]);

                            message.what = 4;//种类
                            message.obj = ParaStr[1];
                        }

                        if (sb.indexOf("COValue")!=-1)
                        {

                            String str=sb.toString();
                            String [] ParaStr=str.split("[-]");
                            Log.d("znjj", ParaStr[0]);
                            Log.d("znjj", ParaStr[1]);

                            message.what = 5;//种类
                            message.obj = ParaStr[1];
                        }

                        if (sb.indexOf("HumanValue")!=-1)   //没用到
                        {

                            String str=sb.toString();
                            String [] ParaStr=str.split("[-]");
                            Log.d("znjj", ParaStr[0]);
                            Log.d("znjj", ParaStr[1]);

                            message.what = 6;//种类
                            message.obj = ParaStr[1];
                        }

                        if (sb.indexOf("smokeAlarm")!=-1)
                        {
                            message.what = 7;//种类
                            //  message.obj=sb;
                        }
                        if (sb.indexOf("COAlarm")!=-1)
                        {
                            message.what = 8;//种类
                            // message.obj=sb;
                        }
                        if (sb.indexOf("HumanAlarm")!=-1)
                        {
                            message.what = 9;//种类
                            //   message.obj=sb;
                        }

                        handler.sendMessage(message);

                        Thread.sleep(500);
                        //------------------- read the response-----------------------------
                    }

                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                catch (InterruptedException e) {

                    e.printStackTrace();
                }

            }
        }.start();



    }


    //按下开灯键后的处理函数
    public void  sendLed1ON(View view)//client socket send fun
    {

        new Thread() {

            @Override
            public void run() {

                try {

                    Socket socket = new Socket(ip, port);
                    OutputStream os = socket.getOutputStream();
                    // byte[] sendbuf = {0x7a, 0x32, 0x55, 0x67};
                    // os.write(sendbuf);
                    os.write("#Led(1)#".getBytes("utf-8"));

                    Thread.sleep(100);
                    socket.close();
                } catch (IOException e) {

                    e.printStackTrace();
                }
                catch (InterruptedException e) {

                    e.printStackTrace();
                }
            }

        }.start();


    }


    //按下关灯键后的处理函数
    public void  sendLed1OFF(View view)//client socket send fun
    {


        new Thread() {

            @Override
            public void run() {

                try {


                    Socket socket = new Socket(ip, port);
                    OutputStream os = socket.getOutputStream();
                    // byte[] sendbuf = {0x7a, 0x32, 0x55, 0x67};
                    // os.write(sendbuf);
                    os.write("#Led(0)#".getBytes("utf-8"));

                    Thread.sleep(100);
                    socket.close();
                } catch (IOException e) {

                    e.printStackTrace();
                }
                catch (InterruptedException e) {

                    e.printStackTrace();
                }
            }

        }.start();


    }
}

