package com.thrid.party.flyingfish.codecplugin;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class ReportProcess {
    //private String identifier;

    private String msgType = "deviceReq";
    private int hasMore = 0;
    private int errcode = 0;
    private byte bDeviceReq = 0x00;
    private byte bDeviceRsp = 0x01;

    private int tempValue = 0;
    private int humiValue = 0;
    private int ntcValue = 0;
    private int smokeValue = 0;
    private int coValue = 0;
    private int humanValue = 0;

    private byte noMid = 0x00;
    private byte hasMid = 0x01;
    private boolean isContainMid = false;
    private int mid = 0;

    /**
     * @param binaryData 设备发送给平台coap报文的payload部分
     *                   本例入参：12 34 56 78 90 00
     *                   byte[0]:   温度
     *                   byte[1]:   湿度
     *                   byte[2]:   光照
     *                   byte[3]:   烟雾
     *                   byte[4]:   一氧化碳
     *                   byte[5]:   是否有人
     * @return
     */
    public ReportProcess(byte[] binaryData) {
        // identifier参数可以根据入参的码流获得，本例指定默认值123
        // identifier = "123";

        /*
        如果是设备上报数据，返回格式为
        {
            "identifier":"123",
            "msgType":"deviceReq",
            "hasMore":0,
            "data":[{"serviceId":"Temperature", "serviceData":{"temperature":12},
                    {"serviceId":"Humidity", "serviceData":{"humidity":34},
                    {"serviceId":"NTC", "serviceData":{"ntc":56},
                    {"serviceId":"Smoke", "serviceData":{"smoke":78},
                    {"serviceId":"CO", "serviceData":{"co":90},
                    {"serviceId":"Human", "serviceData":{"human":00},
                   ]
	    }
	    */

            msgType = "deviceReq";
            hasMore = 0;

            tempValue = binaryData[0];
            humiValue = binaryData[1];
            ntcValue = binaryData[2];
            smokeValue = binaryData[3];
            coValue = binaryData[4];
            humanValue = binaryData[5];

    }

    public ObjectNode toJsonNode() {
        try {
            //组装body体
            ObjectMapper mapper = new ObjectMapper();
            ObjectNode root = mapper.createObjectNode();

            // root.put("identifier", this.identifier);
            root.put("msgType", this.msgType);

            //根据msgType字段组装消息体
            if (this.msgType.equals("deviceReq")) {
                root.put("hasMore", this.hasMore);
                ArrayNode arrynode = mapper.createArrayNode();

                //serviceId=Temperature 数据组装
                ObjectNode tempNode = mapper.createObjectNode();
                tempNode.put("serviceId", "Temperature");
                ObjectNode tempData = mapper.createObjectNode();
                tempData.put("temperature", this.tempValue);
                tempNode.put("serviceData", tempData);
                arrynode.add(tempNode);
                //serviceId=Humidity 数据组装
                ObjectNode humiNode = mapper.createObjectNode();
                humiNode.put("serviceId", "Humidity");
                ObjectNode humiData = mapper.createObjectNode();
                humiData.put("humidity", this.humiValue);
                humiNode.put("serviceData", humiData);
                arrynode.add(humiNode);
                //serviceId=NTC 数据组装
                ObjectNode ntcNode = mapper.createObjectNode();
                ntcNode.put("serviceId", "NTC");
                ObjectNode ntcData = mapper.createObjectNode();
                ntcData.put("ntc", this.ntcValue);
                ntcNode.put("serviceData", ntcData);
                arrynode.add(ntcNode);
                //serviceId=Smoke 数据组装
                ObjectNode smokeNode = mapper.createObjectNode();
                smokeNode.put("serviceId", "Smoke");
                ObjectNode smokeData = mapper.createObjectNode();
                smokeData.put("smoke", this.smokeValue);
                smokeNode.put("serviceData", smokeData);
                arrynode.add(smokeNode);
                //serviceId=CO 数据组装
                ObjectNode coNode = mapper.createObjectNode();
                coNode.put("serviceId", "CO");
                ObjectNode coData = mapper.createObjectNode();
                coData.put("co", this.coValue);
                coNode.put("serviceData", coData);
                arrynode.add(coNode);
                //serviceId=Human 数据组装
                ObjectNode humanNode = mapper.createObjectNode();
                humanNode.put("serviceId", "Human");
                ObjectNode humanData = mapper.createObjectNode();
                humanData.put("human", this.humanValue);
                humanNode.put("serviceData", humanData);
                arrynode.add(humanNode);

                root.put("data", arrynode);

            }
            return root;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}